
# NeuroSprint 🧠

A simple brain workout game designed for:
- Stroke survivors
- Elderly users
- Anyone wanting a quick cognitive boost

## How to Deploy on GitHub Pages

1. Create a new public repository on GitHub.
2. Upload these files to the root of the repository.
3. Go to Settings → Pages.
4. Deploy from the main branch.
5. Your game will be live!

Enjoy!
